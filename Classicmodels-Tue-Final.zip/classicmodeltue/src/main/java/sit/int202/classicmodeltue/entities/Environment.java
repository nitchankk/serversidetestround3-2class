package sit.int202.classicmodeltue.entities;

public class Environment {
    public static final String PUNIT_NANME = "classic-models";
}
